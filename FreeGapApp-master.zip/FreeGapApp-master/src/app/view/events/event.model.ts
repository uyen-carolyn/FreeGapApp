
export class Event {
    public name: string;
    public description: string;
    public date: string;
    public startTime: any;
    public endTime: any;

    constructor(name: string, desc: string, date: string, startTime: any, endTime: any) {
        this.name = name;
        this.description = desc;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;

    }
}

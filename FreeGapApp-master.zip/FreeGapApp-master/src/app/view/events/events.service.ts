import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

import { Event } from './event.model';
import { AuthService } from '../../shared/auth.service';
import { DataStorageService } from '../../shared/data-storage.service';

@Injectable()
export class EventsService {
  eventsChanged = new Subject<Event[]>();

  private events: Event[] = [ ];

  constructor(private authService: AuthService) { }

  setEvents(events: Event[]) {
    this.events = events;
    this.eventsChanged.next(this.events.slice());
  }

  getEvents() {
    return this.events.slice();
  }

  getEvent(index: number) {
    return this.events[index];
  }

  addEvent(event: Event) {
    this.events.push(event);
    this.eventsChanged.next(this.events.slice());
  }

  updateEvent(index: number, newEvent: Event) {
    this.events[index] = newEvent;
    this.eventsChanged.next(this.events.slice());
  }

  deleteEvent(index: number) {
    this.events.splice(index, 1);
    this.eventsChanged.next(this.events.slice());
  }
}

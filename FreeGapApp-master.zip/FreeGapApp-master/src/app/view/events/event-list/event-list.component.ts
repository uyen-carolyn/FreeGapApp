import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { EventsService } from '../events.service';
import { Event } from '../event.model';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.scss']
})
export class EventListComponent implements OnInit, OnDestroy {

  events: Event[];
  subscription: Subscription;

  constructor(private eventService: EventsService,
    private router: Router,
    private route: ActivatedRoute) { }


  ngOnInit() {
    this.subscription = this.eventService.eventsChanged
      .subscribe(
        (events: Event[]) => {
          this.events = events;
        }
      );
      this.events = this.eventService.getEvents();
  }

  onNewEvent() {
    this.router.navigate(['new'], { relativeTo: this.route });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }



}
